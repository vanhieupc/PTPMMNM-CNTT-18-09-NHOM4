def tinh_thue(thu_nhap, giam_tru):
    bac_thue = [(5000000, 0.05), (10000000, 0.1), (18000000, 0.15), 
                (32000000, 0.2), (52000000, 0.25), (80000000, 0.3), 
                (float('inf'), 0.35)]
    
    thu_nhap_tinh_thue = max(0, thu_nhap - giam_tru)
    thue_phai_nop = 0

    for muc, thue_suat in bac_thue:
        if thu_nhap_tinh_thue > muc:
            thue_phai_nop += muc * thue_suat
            thu_nhap_tinh_thue -= muc
        else:
            thue_phai_nop += thu_nhap_tinh_thue * thue_suat
            break
            
    return thue_phai_nop

# Nhập thông tin từ người dùng
try:
    thu_nhap = float(input("Nhập tổng thu nhập (VND): "))
    giam_tru = float(input("Nhập tổng giảm trừ gia cảnh (VND): "))
    
    # Tính toán thuế
    so_thue = tinh_thue(thu_nhap, giam_tru)
    
    # Tạo báo cáo thuế
    print("\n--- Báo cáo thuế ---")
    print(f"Tổng thu nhập: {thu_nhap:,.0f} VND")
    print(f"Giảm trừ gia cảnh: {giam_tru:,.0f} VND")
    print(f"Số thuế phải nộp: {so_thue:,.0f} VND")
except ValueError:
    print("Vui lòng nhập số hợp lệ!")